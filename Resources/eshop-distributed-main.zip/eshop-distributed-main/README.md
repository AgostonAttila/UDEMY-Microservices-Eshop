## .NET Aspire and GenAI Develop Distributed Architectures 2025
https://www.udemy.com/course/net-aspire-and-genai-develop-distributed-architectures/?couponCode=LAUNCH_ASPIRE

Develop AI-Powered Distributed Architectures using .NET Aspire and GenAI to develop EShop Catalog and Basket microservices integrate with Backing services including PostgreSQL, Redis, RabbitMQ, Keycloak, Ollama and Semantic Kernel to Create Intelligent E-Shop Solutions.

![big_picture](https://github.com/user-attachments/assets/7933c4ac-ae45-4a89-907e-0c0545a5fbfd)

This is the EShop Aplication running, performing a **Semantic Search**:
![06eShopLite-SearchSemantic](https://github.com/user-attachments/assets/31353be8-5419-4161-bbac-c0ed5cf42899)

