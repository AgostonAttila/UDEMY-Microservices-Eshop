﻿global using Catalog;
global using Basket;
global using Ordering;