﻿global using Shared.DDD;
global using Catalog.Products.Models;
global using Catalog.Products.Events;