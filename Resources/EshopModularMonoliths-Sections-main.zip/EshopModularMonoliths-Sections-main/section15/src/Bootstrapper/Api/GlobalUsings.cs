﻿global using Catalog;
global using Basket;
global using Ordering;
global using Carter;
global using Shared.Extensions;
global using Shared.Exceptions.Handler;
global using Serilog;