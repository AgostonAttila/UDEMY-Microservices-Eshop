﻿global using Catalog;
global using Basket;
global using Ordering;
global using Carter;
global using Shared.Extensions;