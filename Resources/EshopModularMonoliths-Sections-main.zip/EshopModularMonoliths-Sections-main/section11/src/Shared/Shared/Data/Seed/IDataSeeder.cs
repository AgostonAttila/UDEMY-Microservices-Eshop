﻿namespace Shared.Data.Seed;
public interface IDataSeeder
{
    Task SeedAllAsync();
}
