﻿global using Shared.DDD;
global using Basket.Basket.Models;
global using Microsoft.EntityFrameworkCore;
global using System.Reflection;
global using Basket.Data;