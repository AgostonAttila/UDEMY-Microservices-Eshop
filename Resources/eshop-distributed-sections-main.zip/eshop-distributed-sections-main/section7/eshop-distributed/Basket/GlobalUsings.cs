﻿global using Basket.Models;
global using Basket.Services;
global using Basket.Endpoints;