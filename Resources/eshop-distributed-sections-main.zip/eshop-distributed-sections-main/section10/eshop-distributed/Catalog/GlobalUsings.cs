﻿global using Catalog.Models;
global using Microsoft.EntityFrameworkCore;
global using Catalog.Data;
global using Catalog.Services;
global using Catalog.Endpoints;
global using ServiceDefaults.Messaging;
global using System.Reflection;